$(document).ready(function(){
   $('.hamberger').click(function(){
      $('.navigation').toggleClass('toggle')
   })
})